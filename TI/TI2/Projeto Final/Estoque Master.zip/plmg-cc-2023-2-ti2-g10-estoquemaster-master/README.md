# EstoqueMaster

Projeto focado no controle de estoque para facilitar a organização de empresas de pequeno e médio porte, auxiliando em sua gestão geral.

<img src="Codigo/spark_crud/src/main/resources/public/imgs/logo.png" width="120px">

## Alunos integrantes da equipe

* Túlio Gomes Braga
* Ricardo Soares Pereira da Gama Cerqueira
* Yago Almeida Melo
* Antonio Neto
