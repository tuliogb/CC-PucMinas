# Documentação do Projeto

Documentacao do projeto esta na aba de Divulgacao, separada em power points / videos que foram apresentados ao vivo.