# Artefatos do projeto

* `/divulgacao`
  * Todos os artefatos do projeto estao inseridos na pasta de divulgacao, ja que foram apresentados em aula por meio de power points / videos.
